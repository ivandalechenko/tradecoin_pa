import React from 'react';

const HorizontalLine = (props) => {
    return (
        <div className="hr" />
    )
}

export default HorizontalLine